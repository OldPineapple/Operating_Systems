//
//  kernel.h
//  Assignment2
//
//  Created by OldPineapple on 2020-02-22.
//  Copyright © 2020 Go through the tunnel. All rights reserved.
//

#ifndef kernel_h
#define kernel_h

#include <stdio.h>

void myinit(char *filename);
void scheduler();

#endif /* kernel_h */
