//
//  shell.h
//  Assignment2
//
//  Created by OldPineapple on 2020-02-22.
//  Copyright © 2020 Go through the tunnel. All rights reserved.
//

#ifndef shell_h
#define shell_h

int shellUI();

#endif /* shell_h */
